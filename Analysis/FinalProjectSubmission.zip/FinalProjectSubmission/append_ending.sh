FILES="./*.txt"
for file in $FILES
do
	echo "$f"
	echo "\n*-" >> $file
done
